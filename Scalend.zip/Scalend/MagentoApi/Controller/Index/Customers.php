<?php
 
namespace Scalend\MagentoApi\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 
class Customers extends \Magento\Framework\App\Action\Action
{
     protected $resultJsonFactory;

     public function __construct(
          \Magento\Framework\App\Action\Context $context,
          \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory)
     {
          $this->resultJsonFactory = $resultJsonFactory;
          return parent::__construct($context);
     }

     public function execute()
     {
          try {
               $tokenId = $this->getBearerToken();
               $startDate = $this->getRequest()->getParam('start_date');
               $endDate = $this->getRequest()->getParam('end_date');
               $store_id = $this->getRequest()->getParam('store_id');
               $page=$this->getRequest()->getParam('page');
               $pageSize=$this->getRequest()->getParam('size');
               $storeConfig = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface');
               $tokenConfig = $storeConfig->getValue('scalend_custom_config/general/token', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
               if($tokenId == $tokenConfig && $tokenId) {
                    $customerCollection = $this->_objectManager->create('\Magento\Customer\Model\ResourceModel\Group\Collection');
                    $collection = $customerCollection->create()
                            ->addAttributeToSelect('*');

                    if(!$startDate && !$endDate && !$store_id && !$page) { 
                         $collection = $customerCollection->create()
                            ->addAttributeToSelect('*');
                          
                    } else {
                         $fromDate = date('Y-m-d H:i:s', strtotime($startDate));
                         $toDate = date('Y-m-d H:i:s', strtotime($endDate));
                          
                         if($startDate){
                          $collection->addFieldToFilter('created_at',array('gteq'=>$fromDate));
                         }
                         if($endDate){
                          $collection->addFieldToFilter('created_at',array("lteq" => $toDate));
                         }
                         if($store_id){
                          $collection->addFieldToFilter('store_id', $store_id);
                         }
                        if($page){
                           if($pageSize==''){
                              $pageSize=10;
                           }
                          $collection->setPageSize($pageSize)
                          ->setCurPage($page)
                          ->load();
                        }

                    }
                    if(count($collection) > 0) {
                         $arrData = array();
                         foreach ($collection as $customers){
                              $customerObj = $this->_objectManager->create('Magento\Customer\Model\Customer')->load($customers->getId());

                               $items = [];
                              foreach ($customerObj->getAddresses() as $address)
                              {
                                   $address['entity_id'] = intval($address->getEntityId());
                                   $address['parent_id'] = intval($address->getParentId());
                                   $address['is_active'] = intval($address->getIsActive());
                                   $address['region_id'] = intval($address->getRegionId());
                                   $address['customer_id'] = intval($address->getCustomerId());
                                   $items[] = $address->debug();
                                  
                              }
                              $customerData = $customers->debug();

                              $customerData['entity_id'] = $customers->getEntityId();
                              $customerData['website_id'] = intval($customers->getWebsiteId());
                              $customerData['group_id'] = intval($customers->getGroupId());
                              $customerData['increment_id'] = intval($customers->getIncrementId());
                              $customerData['store_id'] = intval($customers->getStoreId());
                              $customerData['is_active'] = intval($customers->getIsActive());
                              $customerData['disable_auto_group_change'] = intval($customers->getDisableAutoGroupChange());
                              $customerData['taxvat'] = floatval($customers->getTaxVat());
                              $customerData['failures_num'] = intval($customers->getFailuresNum());

                              $customerData['address'] = $items;
                              $arrData[] = $customerData;
                         }
                         $resultData = [ 
                               'customer' => $arrData,
                               'status' => true
                         ]; 
                    } else {
                         throw new \Exception(__("Customer does not exist."));
                    }
               } else {
                    throw new \Exception(__("Token id does not match."));
               }   
          } catch(\Exception $e) {

               $resultData = ['status' => false, 'message' => $e->getMessage()];
          }   
          return  $this->resultJsonFactory->create()->setData($resultData);
          
     }
     public function getAuthorizationHeader(){
        $headers = null;
        if (isset($_SERVER['Authorization'])) {
            $headers = trim($_SERVER["Authorization"]);
        }
        else if (isset($_SERVER['HTTP_AUTHORIZATION'])) { 
            $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
        } elseif (function_exists('apache_request_headers')) {
            $requestHeaders = apache_request_headers();
            $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
            if (isset($requestHeaders['Authorization'])) {
                $headers = trim($requestHeaders['Authorization']);
            }
        }
        return $headers;
    }
    /**
     * get access token from header
     * */
    public function getBearerToken() {
        $headers = $this->getAuthorizationHeader();
        if (!empty($headers)) {
            if (preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
                return $matches[1];
            }
        }
        return null;
    }
}
