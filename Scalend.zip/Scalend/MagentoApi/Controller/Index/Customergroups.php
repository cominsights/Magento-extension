<?php

namespace Scalend\MagentoApi\Controller\Index;

use Magento\Framework\App\Action\Context;

class Customergroups extends \Magento\Framework\App\Action\Action
{
    protected $resultJsonFactory;

    public function __construct(
      \Magento\Framework\App\Action\Context $context,
      \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory)
    {
      $this->resultJsonFactory = $resultJsonFactory;
      return parent::__construct($context);
    }

    public function execute()
    {
      try {
        $tokenId = $this->getBearerToken();
             //  $startDate = $this->getRequest()->getParam('start_date');
             //  $endDate = $this->getRequest()->getParam('end_date');
             //  $store_id = $this->getRequest()->getParam('store_id');
        $page=$this->getRequest()->getParam('page');
       // $field=$this->getRequest()->getParam('field');
       // $value=$this->getRequest()->getParam('value');
      //  $conditionType=$this->getRequest()->getParam('condition_type');
        $pageSize=$this->getRequest()->getParam('page_size');
        $currentPage = $this->getRequest()->getParam('current_page'); 
        $storeConfig = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface');
        $tokenConfig = $storeConfig->getValue('scalend_custom_config/general/token', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        if($tokenId == $tokenConfig && $tokenId) {
          $customerGroup = $this->_objectManager->create('\Magento\Customer\Model\ResourceModel\Group\Collection');

//          $collection = $customerGroup->toOptionArray();

//          if(!$currentPage && !$pageSize) { 
//            $collection = $customerGroup->toOptionArray();
  //        } else {
                       //  $fromDate = date('Y-m-d H:i:s', strtotime($startDate));
                       //  $toDate = date('Y-m-d H:i:s', strtotime($endDate));

                         // if($pageSize){
                         //      $collection->addFieldToFilter('updated_at',array('gteq'=>$fromDate));
                         // }
                         // if($currentPage){
                         //      $collection->addFieldToFilter('updated_at',array("lteq" => $toDate));
                         // }
           // if($currentPage){
//              $collectionGroup->addFieldToFilter('current_page', $currentPage);
            //}
    //        if($page){
      //        if($pageSize==''){
          //      $pageSize=10;
        //      }
  //            $customerGroup->setPageSize($pageSize)
  //            ->setCurPage($page)
//              ->load();
      //      }
    //      }

          if(count($customerGroup) > 0) {
             
            
              $resultData = [ 
                'items' => $customerGroup,
                'status' => true
              ]; 
            
          } else {
            throw new \Exception(__("Order does not exist."));
          }

        }    
      } catch(\Exception $e) {

        $resultData = ['status' => false, 'message' => $e->getMessage()];
      }   
      return  $this->resultJsonFactory->create()->setData($resultData);

    }
    
    public function getCustomerGroups($customerId) {


      $customerGroups = $this->_objectManager->create('\Magento\Customer\Model\ResourceModel\Group\Collection');
      $collection = $customerGroups->create()
                            ->addAttributeToSelect('*');
       $arrData = array();
                         foreach ($collection as $customers){
                              $customerObj = $this->_objectManager->create('Magento\Customer\Model\Group')->load($customers->getCode());

                              
                              foreach ($customerObj as $address)
                              {
                                   $address['entity_id'] = intval($address->getCode());
                                   $address['parent_id'] = intval($address->getTaxClassName());
                                  
                              }
                            }
      return $customerGroups;
    }
    public function getSearchData($field,$value,$conditionType) {
      $arrData = [
        'filter_groups' => [
          [ 
            'filters' => [
              'field' => $field,
              'value' => $value,
              'condition_type' => $conditionType,
            ]
          ]
        ],
        'page_size' => $pageSize,
        'current_page' => $currentPage
      ];
      return $arrData;
    }


    public function getAuthorizationHeader(){
      $headers = null;
      if (isset($_SERVER['Authorization'])) {
        $headers = trim($_SERVER["Authorization"]);
      }
      else if (isset($_SERVER['HTTP_AUTHORIZATION'])) { 
        $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
      } elseif (function_exists('apache_request_headers')) {
        $requestHeaders = apache_request_headers();
        $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
        if (isset($requestHeaders['Authorization'])) {
          $headers = trim($requestHeaders['Authorization']);
        }
      }
      return $headers;
    }
        /**
         * get access token from header
         * */
    public function getBearerToken() {
          $headers = $this->getAuthorizationHeader();
          if (!empty($headers)) {
            if (preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
              return $matches[1];
            }
          }
          return null;
    }
}
