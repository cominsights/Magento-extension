<?php
 
namespace Scalend\MagentoApi\Controller\Index;
 
use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Tree\Node;
 
class Categories extends \Magento\Framework\App\Action\Action
{
     protected $resultJsonFactory;

     public function __construct(
          \Magento\Framework\App\Action\Context $context,
          \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory)
     {
          $this->resultJsonFactory = $resultJsonFactory;
          return parent::__construct($context);
     }

     public function execute()
     {
         try {
             $tree=array();
               $storeFind = false;
               $tokenId = $this->getBearerToken();
               $store_id = $this->getRequest()->getParam('store_id');
               $page=$this->getRequest()->getParam('page');
               $pageSize=$this->getRequest()->getParam('size');
               $storeConfig = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface');
               $tokenConfig = $storeConfig->getValue('scalend_custom_config/general/token', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
               $categoryId=$this->getRequest()->getParam('category_id');
               if($tokenId == $tokenConfig && $tokenId) {

               $storeManager = $this->_objectManager->create("\Magento\Store\Model\StoreManagerInterface");

               $stores = $storeManager->getStores(true, false);

               if($store_id){

                 foreach($stores as $store){

                    if($store->getId() == $store_id){

                        $storeManagerModel = $this->_objectManager->get("\Magento\Store\Model\Store");
                        $storeManagerModel->load($store->getCode());
                        $storeCategoryRootId = $storeManagerModel->getRootCategoryId();
                        
                        $storeFind = true;
                    }
                    else{
                      $tree = ['status' => false, 'message' => 'Store Not found.'];
                    }
                }

               }
            
               $categoryHelper = $this->_objectManager->get('\Magento\Catalog\Helper\Category');

               $categoryRepository = $this->_objectManager->get('\Magento\Catalog\Model\CategoryRepository');

               $categoryFactory = $this->_objectManager->create('Magento\Catalog\Model\ResourceModel\Category\CollectionFactory');

               $categories = $categoryFactory->create()->addAttributeToSelect('*');
               
               $recursionCategory = array();
               $i=0;
               $categorylist=array();
               $catArray = array();
               foreach ($categories as $category){

                      if($store_id){

                      $pathArray = array();

                          $categoriescheck = $categoryRepository->get($category->getId(), $store_id);
                          $pathArray = explode('/', $categoriescheck->getPath());

                          if(!in_array($storeCategoryRootId, $pathArray)){

                           continue;
                          }
                      }

                      if(in_array($category->getId(), $recursionCategory)){

                        continue;
                      }
                      
                      $recursionCategory[] = $category->getId();
                      $subCategory = $category->getChildren();
                      $subCategoryList = array();
                      $j = 0;
                      foreach(explode(',',$subCategory) as $subcat) {
                          $recursionCategory[] = $category->getId();
                          if ($subcat != '') {
                          $subCategoryLoad = $this->_objectManager->create('Magento\Catalog\Model\Category');
                          $subCategoryLoad->load($subcat);

                          $subCategoryList[$j]['id'] = (int) $subCategoryLoad->getId();
                          $subCategoryList[$j]['parent_id'] = (int) $subCategoryLoad->getParentId();
                          $subCategoryList[$j]['name'] = $subCategoryLoad->getName();
                          /*if($category->getIsActive()){
                            $categorylist[$i]['is_active']= "true";
                          }
                          else{
                            $categorylist[$i]['is_active']= "false";
                          }*/
                          $subCategoryList[$j]['position'] = (int) $subCategoryLoad->getPosition();
                          $subCategoryList[$j]['level'] = (int) $subCategoryLoad->getLevel();
                          $subCategoryList[$j]['product_count'] = (int) $subCategoryLoad->getProductCount();
                          $j++;
                          }
                      }
                      $categorylist[$i]['id']= (int) $category->getId();
                      if($category->getIsActive()){
                        $categorylist[$i]['is_active'] = "true";
                      }
                      else{
                        $categorylist[$i]['is_active'] = "false";
                      }
                      $categorylist[$i]['level'] = (int) $category->getLevel();
                      $categorylist[$i]['name'] =  $category->getName();
                      $categorylist[$i]['parent_id'] = (int) $category->getParentId();
                      $categorylist[$i]['position'] = (int) $category->getPosition();
                      $categorylist[$i]['product_count'] = (int) $category->getProductCount();
                      $categorylist[$i]['children_data'] = $subCategoryList;
                      
      
                    $i++;
                }

                $childs = array();
                foreach($categorylist as &$item) $childs[$item['parent_id']][] = &$item;
                unset($item);

                foreach($categorylist as &$item) if (isset($childs[$item['id']]))
                $item['children_data'] = $childs[$item['id']];
                unset($item);
                
                if($categoryId){

                $categoryFilter = array();

                $categoryParent = $this->_objectManager->create('Magento\Catalog\Model\Category')->load($categoryId);

                if($categoryParent){

                      $categoryFilter['id']= (int) $categoryParent->getId();
                      if($categoryParent->getIsActive()){
                        $categoryFilter['is_active'] = "true";
                      }
                      else{
                        $categoryFilter['is_active'] = "false";
                      }
                      $categoryFilter['level'] = (int) $categoryParent->getLevel();
                      $categoryFilter['name'] =  $categoryParent->getName();
                      $categoryFilter['parent_id'] = (int) $categoryParent->getParentId();
                      $categoryFilter['position'] = (int) $categoryParent->getPosition();
                      $categoryFilter['product_count'] = (int) $categoryParent->getProductCount();

                      if(isset($childs[$categoryParent->getId()])){

                        $categoryFilter['children_data'] = $childs[$categoryParent->getId()];

                      }
                      else{
                        $categoryFilter['children_data'] = [];

                      }
                   
                      $tree = $categoryFilter;
                }
                }
                else{
                $tree = $childs[1][0];
                //echo "<pre>";print_r($tree);die;
                }
              /***Pagination  Start***/
              if(! empty($page)){
                if($pageSize==''){
                  $pageSize=5;
                }
              $total = count($tree);     
              $limit = $pageSize;   
              $totalPages = ceil($total/$limit); 
              $page = max($page, 1); 
              $page = min($page, $totalPages); 
              $offset = ($page - 1) * $limit;
              if( $offset < 0 ) $offset = 0;
              $tree = array_slice( $tree, $offset, $limit);
              }
              /***Pagination  End***/
              $resultData=array();
              if($tokenId != $tokenConfig  ) {
                     if(count($stores) > 0) {
                        $i=0;
                       
                        $resultData['status']=true; 
                     }                
              } else {
                    throw new \Exception(__("Token id does not match."));
               }
           } 
           else{

                $tree = ['status' => false, 'message' => 'Token id does not match.'];
           } 
          } catch(\Exception $e) {

               $resultData = ['status' => false, 'message' => $e->getMessage()];
          }

         return $this->resultJsonFactory->create()->setData($tree);
          
     }
      public function getAuthorizationHeader(){
          $headers = null;
          if (isset($_SERVER['Authorization'])) {
              $headers = trim($_SERVER["Authorization"]);
          }
          else if (isset($_SERVER['HTTP_AUTHORIZATION'])) { 
              $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
          } elseif (function_exists('apache_request_headers')) {
              $requestHeaders = apache_request_headers();
              $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
              if (isset($requestHeaders['Authorization'])) {
                  $headers = trim($requestHeaders['Authorization']);
              }
          }
          return $headers;
      }
    
      /**
       * get access token from header
       * */
      public function getBearerToken() {
          $headers = $this->getAuthorizationHeader();
          if (!empty($headers)) {
              if (preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
                  return $matches[1];
              }
          }
          return null;
      }
      public function getBuildTree($categorylist) {

        $childs = array();

        foreach($categorylist as &$item) $childs[$item['parent_id']][] = &$item;
        unset($item);

        foreach($categorylist as &$item) if (isset($childs[$item['id']]))
                $item['children_data'] = $childs[$item['id']];

        return $childs[0];
      }
       public function getSubCategories($id)    {

        $subCategory = array();
        $objectManager =  \Magento\Framework\App\ObjectManager::getInstance();        
        $categoryRepository = $objectManager->get('\Magento\Catalog\Model\CategoryRepository');
        $categoryObj = $categoryRepository->get($id);
        $subcategories = $categoryObj->getChildrenCategories();
        foreach($subcategories as $subcategorie) {
            $this->categoryArray[] = $subcategorie->getId();

            if($subcategorie->hasChildren()){
                $this->getSubCategories($subcategorie->getId());
            }
        }
        
        return $this->categoryArray;        

    }
   
     
}
