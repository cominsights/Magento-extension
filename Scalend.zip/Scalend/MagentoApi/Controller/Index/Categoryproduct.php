<?php
 
namespace Scalend\MagentoApi\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 
class Categoryproduct extends \Magento\Framework\App\Action\Action
{
     protected $resultJsonFactory;

     public function __construct(
          \Magento\Framework\App\Action\Context $context,
          \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory)
     {
          $this->resultJsonFactory = $resultJsonFactory;
          return parent::__construct($context);
     }

     public function execute()
     {
         try {
               $tokenId = $this->getBearerToken();
               $startDate = $this->getRequest()->getParam('start_date');
               $endDate = $this->getRequest()->getParam('end_date');
               $store_id = $this->getRequest()->getParam('store_id');
               $categoryId = $this->getRequest()->getParam('category_id');
               $page=$this->getRequest()->getParam('size');
               $pageSize=$this->getRequest()->getParam('pagesize');
               $storeConfig = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface');
               $tokenConfig = $storeConfig->getValue('scalend_custom_config/general/token', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
               $storeManager = $this->_objectManager->create("\Magento\Store\Model\StoreManagerInterface");
               $stores = $storeManager->getStores(true, false);
               $categoryFactory = $this->_objectManager->get('\Magento\Catalog\Model\CategoryFactory');              
               $category = $categoryFactory->create()->load($categoryId);
               $categoryProducts = $category->getProductCollection()->addAttributeToSelect('*');
               if(!$startDate && !$endDate && !$store_id && !$page) {
                     $categoryProducts = $category->getProductCollection()->addAttributeToSelect('*');
               }else{
                    if($page){
                         if($pageSize==''){
                              $pageSize=10;
                         }
                         $categoryProducts->setPageSize($pageSize)
                         ->setCurPage($page)
                         ->load();
                    }
                    $fromDate = date('Y-m-d H:i:s', strtotime($startDate));
                    $toDate = date('Y-m-d H:i:s', strtotime($endDate));
                  
                   if($startDate){
                    //die("sdsf1");
                     $categoryProducts->addFieldToFilter('created_at',array('gteq'=>$fromDate));
                   }
                   if($endDate){
                     $categoryProducts->addFieldToFilter('created_at',array("lteq" => $toDate));
                   }
                   if($store_id){
                     $categoryProducts->addStoreFilter($store_id);
                   }
                   
               }
              $resultData=array();
               if($tokenId == $tokenConfig) {
                     if(count($categoryProducts) > 0) {
                        $i=0;
                         foreach ($categoryProducts as $product) {
                              $resultData[$i]['sku'] = $product->getSku();
                              $resultData[$i]['position'] = (int) $product->getCatIndexPosition();
                              $resultData[$i]['category_id'] = (int) $categoryId;
                              $i++;
                         }
                        $resultData['status']=true; 
                     }
                     else{
                         throw new \Exception(__("Not Found any product.")); 
                     }                
               } else {
                    throw new \Exception(__("Token id does not match."));
               }   
          } catch(\Exception $e) {

               $resultData = ['status' => false, 'message' => $e->getMessage()];
          }   
         return $this->resultJsonFactory->create()->setData($resultData);
          
     }
      public function getAuthorizationHeader(){
          $headers = null;
          if (isset($_SERVER['Authorization'])) {
              $headers = trim($_SERVER["Authorization"]);
          }
          else if (isset($_SERVER['HTTP_AUTHORIZATION'])) { 
              $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
          } elseif (function_exists('apache_request_headers')) {
              $requestHeaders = apache_request_headers();
              $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
              if (isset($requestHeaders['Authorization'])) {
                  $headers = trim($requestHeaders['Authorization']);
              }
          }
          return $headers;
      }
      /**
       * get access token from header
       * */
      public function getBearerToken() {
          $headers = $this->getAuthorizationHeader();
          if (!empty($headers)) {
              if (preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
                  return $matches[1];
              }
          }
          return null;
      }
     
}
