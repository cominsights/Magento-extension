<?php

namespace Scalend\MagentoApi\Controller\Index;

use Magento\Framework\App\Action\Context;

class Coupons extends \Magento\Framework\App\Action\Action
{
    protected $resultJsonFactory;

    public function __construct(
      \Magento\Framework\App\Action\Context $context,
      \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory)
    {
      $this->resultJsonFactory = $resultJsonFactory;
      return parent::__construct($context);
    }

    public function execute()
    {
      try {
        $tokenId = $this->getBearerToken();
             //  $startDate = $this->getRequest()->getParam('start_date');
             //  $endDate = $this->getRequest()->getParam('end_date');
             //  $store_id = $this->getRequest()->getParam('store_id');
        $page=$this->getRequest()->getParam('page');
       // $field=$this->getRequest()->getParam('field');
       // $value=$this->getRequest()->getParam('value');
      //  $conditionType=$this->getRequest()->getParam('condition_type');
        $pageSize=$this->getRequest()->getParam('page_size');
        $currentPage = $this->getRequest()->getParam('current_page'); 
        $storeConfig = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface');
        $tokenConfig = $storeConfig->getValue('scalend_custom_config/general/token', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        if($tokenId == $tokenConfig && $tokenId) {
          $coupons = $this->_objectManager->create('Magento\SalesRule\Model\Coupon');

         
          if(!$currentPage && !$pageSize) { 
            // $collection = $coupons->create()
            // ->getData();
          } else {
                       //  $fromDate = date('Y-m-d H:i:s', strtotime($startDate));
                       //  $toDate = date('Y-m-d H:i:s', strtotime($endDate));

                         // if($pageSize){
                         //      $collection->addFieldToFilter('updated_at',array('gteq'=>$fromDate));
                         // }
                         // if($currentPage){
                         //      $collection->addFieldToFilter('updated_at',array("lteq" => $toDate));
                         // }
            if($currentPage){
              $collection->addFieldToFilter('current_page', $currentPage);
            }
            if($page){
              if($pageSize==''){
                $pageSize=10;
              }
              $collection->setPageSize($pageSize)
              ->setCurPage($page)
              ->load();
            }
          }

          if(count($collection) > 0) {
            $arrData = array();
           // foreach ($collection as $coupons){

              $couponData['items'] = [ 
           'coupon_id'=> $coupons->getCouponId(),
            'rule_id'=> $coupons->getRuleId(),
            'code'=> $coupons->getCode(),
            'usage_limit'=>$coupons->getUsageLimit(),
            'usage_per_customer'=>$coupons->getUsagePerCustomer(),
            'times_used'=> $coupons->getTimesUsed(),
            'is_primary'=> $coupons->getIsPrimary(),
            'created_at'=>$coupons->getCreatedAt(),
            'type'=> $coupons->getType()
        ];
              $arrData = $couponData;
             
            // if(!$startDate && !$endDate) { 
            //   $resultData = [ 
            //     'items' => $arrData,
            //     'status' => true
            //   ]; 
            } else {
              $resultData = [ 
                'items' => $arrData,
              //  'search_criteria' => $this->getSearchData($field,$value,$conditionType),
                'total_count' => count($arrData)
              ]; 
            }
          } else {
            throw new \Exception(__("Coupon does not exist."));
          }

        } catch(\Exception $e) {

        $resultData = ['status' => false, 'message' => $e->getMessage()];
      } 
        if(!$currentPage && !$page){
        	throw new \Exception("%fieldname is the required field");
        	

        }
        else {
          throw new \Exception(__("Token id does not match."));
        }   
       
      return  $this->resultJsonFactory->create()->setData($resultData);

    }
    
    public function getCoupons() {

      $customerGroups = $this->_objectManager->create('\Magento\SalesRule\Model\ResourceModel\Coupon\CollectionFactory');
      $items = [];
      foreach ($customerGroups as $item) {

        $arrItems = [ 
           'coupon_id'=> $item->getCouponId(),
            'rule_id'=> $item->getRuleId(),
            'code'=> $item->getCode(),
            'usage_limit'=>$item->getUsageLimit(),
            'usage_per_customer'=>$item->getUsagePerCustomer(),
            'times_used'=> $item->getTimesUsed(),
            'is_primary'=> $item->getIsPrimary(),
            'created_at'=>$item->getCreatedAt(),
            'type'=> $item->getType()
        ];

        
      } 
	  $customerGroups[] = $arrItems;
      return $customerGroups;
    }
    public function getSearchData($field,$value,$conditionType) {
      $arrData = [
        'filter_groups' => [
          [ 
            'filters' => [
              'field' => $field,
              'value' => $value,
              'condition_type' => $conditionType,
            ]
          ]
        ],
        'page_size' => $pageSize,
        'current_page' => $currentPage
      ];
      return $arrData;
    }


    public function getAuthorizationHeader(){
      $headers = null;
      if (isset($_SERVER['Authorization'])) {
        $headers = trim($_SERVER["Authorization"]);
      }
      else if (isset($_SERVER['HTTP_AUTHORIZATION'])) { 
        $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
      } elseif (function_exists('apache_request_headers')) {
        $requestHeaders = apache_request_headers();
        $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
        if (isset($requestHeaders['Authorization'])) {
          $headers = trim($requestHeaders['Authorization']);
        }
      }
      return $headers;
    }
        /**
         * get access token from header
         * */
    public function getBearerToken() {
          $headers = $this->getAuthorizationHeader();
          if (!empty($headers)) {
            if (preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
              return $matches[1];
            }
          }
          return null;
    }
}
