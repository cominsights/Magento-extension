<?php
 
namespace Scalend\MagentoApi\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 
class Orders extends \Magento\Framework\App\Action\Action
{
     protected $resultJsonFactory;

     public function __construct(
          \Magento\Framework\App\Action\Context $context,
          \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory)
     {
          $this->resultJsonFactory = $resultJsonFactory;
          return parent::__construct($context);
     }

     public function execute()
     {
          try {
               $tokenId = $this->getBearerToken();
               $startDate = $this->getRequest()->getParam('start_date');
               $endDate = $this->getRequest()->getParam('end_date');
               $store_id = $this->getRequest()->getParam('store_id');
               $page=$this->getRequest()->getParam('page');
               $pageSize=$this->getRequest()->getParam('size');
               $storeConfig = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface');
               $tokenConfig = $storeConfig->getValue('scalend_custom_config/general/token', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
               if($tokenId == $tokenConfig && $tokenId) {
                    $orderCollection = $this->_objectManager->create('Magento\Sales\Model\ResourceModel\Order\CollectionFactory');

                    $collection = $orderCollection->create()
                          ->addAttributeToSelect('*');
                          
                    if(!$startDate && !$endDate && !$store_id && !$page) { 
                         $collection = $orderCollection->create()
                            ->addAttributeToSelect('*');
                    } else {
                         $fromDate = date('Y-m-d H:i:s', strtotime($startDate));
                         $toDate = date('Y-m-d H:i:s', strtotime($endDate));
                        
                         if($startDate){
                              $collection->addFieldToFilter('updated_at',array('gteq'=>$fromDate));
                         }
                         if($endDate){
                              $collection->addFieldToFilter('updated_at',array("lteq" => $toDate));
                         }
                         if($store_id){
                              $collection->addFieldToFilter('store_id', $store_id);
                         }
                         if($page){
                              if($pageSize==''){
                                   $pageSize=10;
                              }
                              $collection->setPageSize($pageSize)
                              ->setCurPage($page)
                              ->load();
                        }
                    }

                    if(count($collection) > 0) {
                         $arrData = array();
                         foreach ($collection as $orders){
                              $orderArr = [
                                  'base_currency_code' => $orders->getBaseCurrencyCode(),
                                  'base_discount_amount' => (int) $orders->getBaseDiscountAmount(),
                                  'base_grand_total' => (int) $orders->getBaseGrandTotal(),
                                  'base_discount_tax_compensation_amount' => (int) $orders->getBaseDiscountTaxCompensationAmount(),
                                  'base_shipping_amount' => (int) $orders->getBaseShippingAmount(),
                                  'base_shipping_discount_amount' => (int) $orders->getBaseShippingDiscountAmount(),
                                  'base_shipping_incl_tax' => (int) $orders->getBaseShippingInclTax(),
                                  'base_shipping_tax_amount' => (int) $orders->getBaseShippingTaxAmount(),
                                  'base_subtotal' => (int) $orders->getBaseSubtotal(),
                                  'base_subtotal_incl_tax' => (int) $orders->getBaseSubtotalInclTax(),
                                  'base_tax_amount' =>  (int) $orders->getBaseTaxAmount(),
                                  'base_total_due' => (int) $orders->getBaseTotalDue(),
                                  'base_to_global_rate' => (int) $orders->getBaseToGlobalRate(),
                                  'base_to_order_rate' => (int) $orders->getBaseToOrderRate(),
                                  'billing_address_id' => (int) $orders->getBillingAddressId(),
                                  'created_at' => $orders->getCreatedAt(),
                                  'customer_email' => $orders->getCustomerEmail(),
                                  'customer_firstname' => $orders->getCustomerFirstname(),
                                  'customer_group_id' => (int) $orders->getCustomerGroupId(),
                                  'customer_id' => (int) $orders->getCustomerId(),
                                  'customer_is_guest' => (int) $orders->getCustomerIsGuest(),
                                  'customer_lastname' => $orders->getCustomerLastname(),
                                  'customer_note_notify' => (int) $orders->getCustomerNoteNotify(),
                                  'discount_amount' => (int) $orders->getDiscountAmount(),
                                  'email_sent' =>(int) $orders->getEmailSent(),
                                  'entity_id' => (int) $orders->getEntityId(),
                                  'global_currency_code' => $orders->getGlobalCurrencyCode(),
                                  'grand_total' => (int) $orders->getGrandTotal(),
                                  'discount_tax_compensation_amount' => (int) $orders->getDiscountTaxCompensationAmount(),
                                  'increment_id' => (int) $orders->getIncrementId(),
                                  'is_virtual' => intval($orders->getIsVirtual()),
                                  'order_currency_code' => $orders->getOrderCurrencyCode(),
                                  'protect_code' => $orders->getProtectCode(),
                                  'quote_id' => (int) $orders->getQuoteId(),
                                  'remote_ip' => $orders->getRemoteIp(),
                                  'shipping_amount' => (int) $orders->getShippingAmount(),
                                  'shipping_description' => $orders->getShippingDescription(),
                                  'shipping_discount_amount' => (int) $orders->getShippingDiscountAmount(),
                                  'shipping_discount_tax_compensation_amount' => (int) $orders->getShippingDiscountTaxCompensationAmount(),
                                  'shipping_incl_tax' => (int) $orders->getShippingInclTax(),
                                  'shipping_tax_amount' => (int) $orders->getShippingTaxAmount(),
                                  'state' => $orders->getState(),
                                  'status' => $orders->getStatus(),
                                  'store_currency_code' => $orders->getStoreCurrencyCode(),
                                  'store_id' => (int) $orders->getStoreId(),
                                  'store_name' => $orders->getStoreName(),
                                  'store_to_base_rate' => (int) $orders->getStoreToBaseRate(),
                                  'store_to_order_rate' => (int) $orders->getStoreToOrderRate(),
                                  'subtotal' => (int) $orders->getSubtotal(),
                                  'subtotal_incl_tax' => (int) $orders->getSubtotalInclTax(),
                                  'tax_amount' => (int) $orders->getTaxAmount(),
                                  'total_due' => (int) $orders->getTotalDue(),
                                  'total_item_count' => (int) $orders->getTotalItemCount(),
                                  'total_qty_ordered' => (int) $orders->getTotalQtyOrdered(),
                                  'updated_at' => $orders->getUpdatedAt(),
                                  'weight' => (int) $orders->getWeight(),
                              ];

                              $orderData = $orderArr;
                              $orderData['items'] =$this->getProductItems($orders->getId());

                              $orderData['billing_address'] = $this->getBillingData($orders->getId());
                              //$orderData['shipping_address'] = $this->getShippingData($orders->getId());
                              $orderData['payment'] = $this->getPaymentData($orders->getId());
                              $orderData['status_histories'] = $this->getStatusData($orders->getId());
                              $orderData['extension_attributes'] = $this->getExtensionData($orders->getId());
                              $arrData[] = $orderData;
                         }  
                        if(!$startDate && !$endDate) { 
                           $resultData = [ 
                                 'items' => $arrData,
                                 'total_count' => count($arrData)
                                 //'status' => true
                           ]; 
                       } else {
                          $resultData = [ 
                                 'items' => $arrData,
                                 'search_criteria' => $this->getSearchData($fromDate,$toDate,$orders->getStoreId()),
                                // 'status' => true
                                 'total_count' => count($arrData)
                           ]; 
                       }
                    } else {
                         throw new \Exception(__("Order does not exist."));
                    }
                    
               } else {
                    throw new \Exception(__("Token id does not match."));
               }   
          } catch(\Exception $e) {

               $resultData = ['status' => false, 'message' => $e->getMessage()];
          }   
          return  $this->resultJsonFactory->create()->setData($resultData);
          
     }
      public function getAuthorizationHeader(){
          $headers = null;
          if (isset($_SERVER['Authorization'])) {
              $headers = trim($_SERVER["Authorization"]);
          }
          else if (isset($_SERVER['HTTP_AUTHORIZATION'])) { 
              $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
          } elseif (function_exists('apache_request_headers')) {
              $requestHeaders = apache_request_headers();
              $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
              if (isset($requestHeaders['Authorization'])) {
                  $headers = trim($requestHeaders['Authorization']);
              }
          }
          return $headers;
      }
      /**
       * get access token from header
       * */
      public function getBearerToken() {
          $headers = $this->getAuthorizationHeader();
          if (!empty($headers)) {
              if (preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
                  return $matches[1];
              }
          }
          return null;
      }
      public function getProductItems($orderId) {
           $order = $this->_objectManager->create('Magento\Sales\Api\Data\OrderInterface')->load($orderId);
            $items = [];
            foreach ($order->getAllItems() as $item) {
                $arrItems = [
                      'amount_refunded' => (int) $item->getAmountRefunded(),
                      'base_amount_refunded' => (int) $item->getBaseAmountRefunded(),
                      'base_discount_amount' => (int) $item->getBaseDiscountAmount(),
                      'base_discount_invoiced' => (int) $item->getBaseDiscountInvoiced(),
                      'base_discount_tax_compensation_amount' => (int) $item->getBaseDiscountTaxCompensationAmount(),
                      'base_original_price' => (int) $item->getBaseOriginalPrice(),
                      'base_price' => (int) $item->getBasePrice(),
                      'base_price_incl_tax' => (int) $item->getBasePriceInclTax(),
                      'base_row_invoiced' => (int) $item->getBaseRowInvoiced(),
                      'base_row_total' => (int) $item->getBaseRowTotal(),
                      'base_row_total_incl_tax' => (int) $item->getBaseRowTotalInclTax(),
                      'base_tax_amount' => (int) $item->getBaseTaxAmount(),
                      'base_tax_invoiced' => (int) $item->getBaseTaxInvoiced(),
                      'created_at' => $item->getCreatedAt(),
                      'discount_amount' => (int) $item->getDiscountAmount(),
                      'discount_invoiced' => (int) $item->getDiscountInvoiced(),
                      'discount_percent' => (int) $item->getDiscountPercent(),
                      'free_shipping' => $item->getFreeShipping(),
                      'discount_tax_compensation_amount' => (int) $item->getDiscountTaxCompensationAmount(),
                      'is_qty_decimal' => $item->getIsQtyDecimal(),
                      'is_virtual' => (int) $item->getIsVirtual(),
                      'item_id' => (int) $item->getItemId(),
                      'name' => $item->getName(),
                      'no_discount' => $item->getNoDiscount(),
                      'order_id' => (int) $item->getOrderId(),
                      'original_price' => (int) $item->getOriginalPrice(),
                      'price' => (int) $item->getPrice(),
                      'price_incl_tax' => (int) $item->getPriceInclTax(),
                      'product_id' => (int) $item->getProductId(),
                      'product_type' => $item->getProductType(),
                      'qty_canceled' => (int) $item->getQtyCanceled(),
                      'qty_invoiced' => (int) $item->getQtyInvoiced(),
                      'qty_ordered' => (int) $item->getQtyOrdered(),
                      'qty_refunded' => (int) $item->getQtyRefunded(),
                      'qty_shipped' => (int) $item->getQtyShipped(),
                      'quote_item_id' => (int)  $item->getQuoteItemId(),
                      'row_invoiced' => (int) $item->getRowInvoiced(),
                      'row_total' => (int) $item->getRowTotal(),
                      'row_total_incl_tax' => (int) $item->getRowTotalInclTax(),
                      'row_weight' => (int) $item->getRowWeight(),
                      'sku' => $item->getSku(),
                      'store_id' => (int) $item->getStoreId(),
                      'tax_amount' => (int) $item->getTaxAmount(),
                      'tax_invoiced' => (int) $item->getTaxInvoiced(),
                      'tax_percent' => (int) $item->getTaxPercent(),
                      'updated_at' => $item->getUpdatedAt(),
                      'weight' => (int) $item->getWeight(),
                ];
                $items[] = $arrItems;
            }
            return $items;
      }
      public function getBillingData($orderId) {
           $order = $this->_objectManager->create('Magento\Sales\Api\Data\OrderInterface')->load($orderId);
            $arrData = [
                'address_type' => $order->getBillingAddress()->getAddressType(),
                'city' => $order->getBillingAddress()->getCity(),
                'country_id' => $order->getBillingAddress()->getCountryId(),
                'customer_address_id' => $order->getBillingAddress()->getCustomerAddressId(),
                'email' => $order->getBillingAddress()->getEmail(),
                'entity_id' => (int) $order->getBillingAddress()->getId(),
                'firstname' => $order->getBillingAddress()->getFirstname(),
                'lastname' => $order->getBillingAddress()->getLastname(),
                'parent_id' => (int) $order->getBillingAddress()->getParentId(),
                'postcode' => $order->getBillingAddress()->getPostcode(),
                'region' => $order->getBillingAddress()->getRegion(),
                'region_code'=>$order->getBillingAddress()->getRegionCode(),
                'region_id' => (int) $order->getBillingAddress()->getRegionId(),
                'street' =>  $order->getBillingAddress()->getStreet(),
                'telephone' => $order->getPayment()->getTelephone(),
            ];
            return $arrData;
      }
      public function getShippingData($orderId) {
           $order = $this->_objectManager->create('Magento\Sales\Api\Data\OrderInterface')->load($orderId);
           $arrData = [
                'address_type' => $order->getBillingAddress()->getAddressType(),
                'city' => $order->getBillingAddress()->getCity(),
                'country_id' => $order->getBillingAddress()->getCountryId(),
                'customer_address_id' => $order->getBillingAddress()->getCustomerAddressId(),
                'email' => $order->getBillingAddress()->getEmail(),
                'entity_id' => (int) $order->getBillingAddress()->getId(),
                'firstname' => $order->getBillingAddress()->getFirstname(),
                'lastname' => $order->getBillingAddress()->getLastname(),
                'parent_id' => (int) $order->getBillingAddress()->getParentId(),
                'postcode' => $order->getBillingAddress()->getPostcode(),
                'region' => $order->getBillingAddress()->getRegion(),
                'region_code'=>$order->getBillingAddress()->getRegionCode(),
                'region_id' => (int) $order->getBillingAddress()->getRegionId(),
                'street' =>  $order->getBillingAddress()->getStreet(),
                'telephone' => $order->getPayment()->getTelephone(),
            ];
            return $arrData;
      }
      public function getPaymentData($orderId) {
           $order = $this->_objectManager->create('Magento\Sales\Api\Data\OrderInterface')->load($orderId);
           $arrData = [
                  'account_status' => $order->getPayment()->getState(),
                  'additional_information' =>  $order->getPayment()->getAdditionalInformation(),
                  'amount_ordered' => (int) $order->getPayment()->getAmountOrdered(),
                  'base_amount_ordered' => (int) $order->getPayment()->getBaseAmountOrdered(),
                  'base_shipping_amount' => (int) $order->getPayment()->getBaseShippingAmount(),
                  'cc_last4' => $order->getPayment()->getCcLast4(),
                  'entity_id' => (int) $order->getPayment()->getId(),
                  'method' => $order->getPayment()->getMethod(),
                  'parent_id' => (int) $order->getPayment()->getParentId(),
                  'shipping_amount' => (int) $order->getPayment()->getShippingAmount(),
                ];
            return $arrData;
      }
      public function getExtensionData($orderId) {
            $this->serviceOutputProcessor = $this->_objectManager->create('Magento\Framework\Webapi\ServiceOutputProcessor');
          $service = $this->_objectManager->create('Magento\Sales\Api\OrderRepositoryInterface');

        $outputData = call_user_func_array([$service, 'get'], [$orderId]);
          $outputData = $this->serviceOutputProcessor->process(
            $outputData,
            'Magento\Sales\Api\OrderRepositoryInterface',
            'get'
          );

            return $outputData['extension_attributes'];
      }
      public function getStatusData($orderId) {
           $order = $this->_objectManager->create('Magento\Sales\Api\Data\OrderInterface')->load($orderId);
      if($order->getStatusHistories()==null){
          return $order->getStatusHistories();
     }
     else{
      $arrData = [
		            'comment'=>$order->getStatusHistories()->getComment(),
		            'created_at'=>$order->getStatusHistories()->getCreatedAt(),
		            'entity_id'=>(int)$order->getStatusHistories()->getEntityId(),
		            'entity_name'=>$order->getStatusHistories()->getEntityName(),
		            'is_costumer_notified'=>$order->getStatusHistories()->getIsCustomerNotified(),
		            'is_visible_on_front'=>$order->getStatusHistories()->getIsVisibleOnFront(),
		            'parent_id'=>(int)$order->getStatusHistories()->getParentId(),
		            'status'=>$order->getStatusHistories()->getStatus(),
                 ];
            return $arrData;
      }     // return $order->getStatusHistories();
      }
      public function getSearchData($fromDate,$toDate,$storeId) {
         $arrData = [
            'filter_groups' => [
                  [ 
                    'filters' => [
                        'field' => 'updated_at',
                        'value' => $fromDate,
                        'condition_type' => 'gt',
                    ],
                  ],
                  [ 
                    'filters' => [
                        'field' => 'updated_at',
                        'value' => $toDate,
                        'condition_type' => 'lt',
                    ]
                  ],
                  [ 
                    'filters' => [
                        'field' => 'store_id',
                        'value' => $storeId,
                        'condition_type' => 'eq',
                    ]
                  ]
              ]
          ];
         return $arrData;
      }
}
