<?php
 
namespace Scalend\MagentoApi\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 
class Quotes extends \Magento\Framework\App\Action\Action
{
     protected $resultJsonFactory;

     public function __construct(
          \Magento\Framework\App\Action\Context $context,
          \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory)
     {
          $this->resultJsonFactory = $resultJsonFactory;
          return parent::__construct($context);
     }

     public function execute()
     {
          try {
              $tokenId = $this->getBearerToken();
              $startDate = $this->getRequest()->getParam('start_date');
              $endDate = $this->getRequest()->getParam('end_date');
              $store_id = $this->getRequest()->getParam('store_id');
              $page=$this->getRequest()->getParam('page');
              $pageSize=$this->getRequest()->getParam('size');
              $storeConfig = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface');
              $tokenConfig = $storeConfig->getValue('scalend_custom_config/general/token', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
              $quoteCollection = $this->_objectManager->create("Magento\Quote\Model\Quote")->getCollection();

              if(!$startDate && !$endDate && !$store_id & !$page) { 
                  $quoteCollection->addFieldToFilter('is_active', 1);
              } else {
                    $fromDate = date('Y-m-d H:i:s', strtotime($startDate));
                    $toDate = date('Y-m-d H:i:s', strtotime($endDate));
                    $quoteCollection->addFieldToFilter('is_active', 1);
                    if($page){
                       if($pageSize==''){
                              $pageSize=10;
                         }
                      $quoteCollection->setPageSize($pageSize)
                      ->setCurPage($page)
                      ->load();
                    }
                    if($startDate){
                         $quoteCollection->addFieldToFilter('created_at',array('gteq'=>$fromDate));
                    }
                    if($endDate){
                         $quoteCollection->addFieldToFilter('created_at',array("lteq" => $toDate));
                    }
                    if($store_id){
                         $quoteCollection->addFieldToFilter('store_id', $store_id);
                    }
              }
              if($tokenId == $tokenConfig && $tokenId) {
                if(count($quoteCollection) > 0) {
                    $resultData = [];
                    foreach($quoteCollection as $quote) {

                        $items = [];
                        foreach( $quote->getAllVisibleItems() as $item ) {

                            $items[] = $item->debug();
                        }

                        $data =  $quote->debug();
                        $data['items'] =  $items;

                        $resultData[] = $data;
                    }
                    $resultData = [ 
                           'quote' => $resultData,
                           'status' => true
                    ]; 
                  } else {
                       throw new \Exception(__("Quote data does not exist."));
                  }
              } else {
                  throw new \Exception(__("Token id does not match."));
              }
          } catch(\Exception $e) {

               $resultData = ['status' => false, 'message' => $e->getMessage()];
          }   
          return  $this->resultJsonFactory->create()->setData($resultData);
     }
     public function getAuthorizationHeader(){
          $headers = null;
          if (isset($_SERVER['Authorization'])) {
              $headers = trim($_SERVER["Authorization"]);
          }
          else if (isset($_SERVER['HTTP_AUTHORIZATION'])) { 
              $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
          } elseif (function_exists('apache_request_headers')) {
              $requestHeaders = apache_request_headers();
              $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
              if (isset($requestHeaders['Authorization'])) {
                  $headers = trim($requestHeaders['Authorization']);
              }
          }
          return $headers;
      }
      /**
       * get access token from header
       * */
      public function getBearerToken() {
          $headers = $this->getAuthorizationHeader();
          if (!empty($headers)) {
              if (preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
                  return $matches[1];
              }
          }
          return null;
      }
}
