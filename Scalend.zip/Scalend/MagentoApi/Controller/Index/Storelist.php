<?php
 
namespace Scalend\MagentoApi\Controller\Index;
 
use Magento\Framework\App\Action\Context;
 
class Storelist extends \Magento\Framework\App\Action\Action
{
     protected $resultJsonFactory;

     public function __construct(
          \Magento\Framework\App\Action\Context $context,
          \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory)
     {
          $this->resultJsonFactory = $resultJsonFactory;
          return parent::__construct($context);
     }

     public function execute()
     {
         try {
              $tokenId = $this->getBearerToken();
              $page=$this->getRequest()->getParam('page');
              $pageSize=$this->getRequest()->getParam('size');
              $storeConfig = $this->_objectManager->get('Magento\Framework\App\Config\ScopeConfigInterface');
              $tokenConfig = $storeConfig->getValue('scalend_custom_config/general/token', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
              $storeManager = $this->_objectManager->create("\Magento\Store\Model\StoreManagerInterface");
                 
              $stores = $storeManager->getStores(true, false);
               if($page){
                    if($pageSize==''){
                         $pageSize=10;
                    }
                    $total = count($stores);     
                    $limit = $pageSize;   
                    $totalPages = ceil($total/$limit); 
                    $page = max($page, 1); 
                    $page = min($page, $totalPages); 
                    $offset = ($page - 1) * $limit;
                    if( $offset < 0 ) $offset = 0;
                    $stores = array_slice( $stores, $offset, $limit);
               }
              $resultData=array();
               if($tokenId == $tokenConfig && $tokenId) {

                     if(count($stores) > 0) {
                        $i=0;
                        foreach($stores as $store){
                             $resultData[$i]['store_id'] = (int) $store->getId();
                             $resultData[$i]['code'] = $store->getCode();
                             $resultData[$i]['website_id'] = (int) $store->getWebsiteId();
                             $resultData[$i]['group_id'] = (int) $store->getGroupId();
                             $resultData[$i]['name'] = $store->getName();
                             $resultData[$i]['sort_order'] = (int) $store->getSortOrder();
                             $resultData[$i]['is_active'] = (int) $store->getIsActive();
                             $i++;
                        }
                        $resultData['status']=true; 
                     }                
               } else {
                    throw new \Exception(__("Token id does not match."));
               }   
          } catch(\Exception $e) {

               $resultData = ['status' => false, 'message' => $e->getMessage()];
          }   
         return $this->resultJsonFactory->create()->setData($resultData);
          
     }
      public function getAuthorizationHeader(){
          $headers = null;
          if (isset($_SERVER['Authorization'])) {
              $headers = trim($_SERVER["Authorization"]);
          }
          else if (isset($_SERVER['HTTP_AUTHORIZATION'])) { 
              $headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
          } elseif (function_exists('apache_request_headers')) {
              $requestHeaders = apache_request_headers();
              $requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
              if (isset($requestHeaders['Authorization'])) {
                  $headers = trim($requestHeaders['Authorization']);
              }
          }
          return $headers;
      }
      /**
       * get access token from header
       * */
      public function getBearerToken() {
          $headers = $this->getAuthorizationHeader();
          if (!empty($headers)) {
              if (preg_match('/Bearer\s(\S+)/', $headers, $matches)) {
                  return $matches[1];
              }
          }
          return null;
      }
     
}
